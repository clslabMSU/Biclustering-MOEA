### R code from vignette source 'fabia.Rnw'

###################################################
### code chunk number 1: fabia.Rnw:45-49
###################################################
options(width=75)
set.seed(0)
library(fabia)
fabiaVer<-packageDescription("fabia")$Version


